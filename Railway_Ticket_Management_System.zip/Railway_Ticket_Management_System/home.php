<?php 
	require "header.php";

	include "User_login.php";
 ?>


 <?php 
 	require "footer.php";
  ?>