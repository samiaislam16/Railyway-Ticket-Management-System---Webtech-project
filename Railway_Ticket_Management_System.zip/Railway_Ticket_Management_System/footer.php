<?php 
	echo "<p>copy right &copy".date("Y")."to fahad tech.</p>";
 ?>