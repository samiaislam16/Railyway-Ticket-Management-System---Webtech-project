<!DOCTYPE html>
<html>
<head>
	<title>this is the header.</title>
</head>
<body>
	<header>
		<nav>
			<a href="#">
				<img src="logo.png" alt="logo">
			</a>
			<ul>
				<li><a href="home.php">HOME</a></li>
				<li><a href="#">portpholio</a></li>
				<li><a href="#">About</a></li>
				<li><a href="#">Contact</a></li>
                <li><a href="User_registration.php">Registraion</a></li>
			</ul>
			<div>
				<form action="includes/login.inc.php" method="post">
					
				</form>
			</div>
		</nav>
	</header>

</body>
</html>