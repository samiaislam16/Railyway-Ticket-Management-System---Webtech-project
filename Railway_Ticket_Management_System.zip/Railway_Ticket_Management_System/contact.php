<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Customer home page</title>
        <link rel="stylesheet" type="text/css" href="style/homeStyle.css">

</head>

<body>
    <?php
    include('customerHeader.php');
    ?>
    <div class="welcome">
        <h3>GMAIL:bdrailway@gmail.com</h3>
        <h3>PHONE:016-XXXXXXXXXX</h3>
    </div>
</body>

</html>