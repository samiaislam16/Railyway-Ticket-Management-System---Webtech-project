<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Customer home page</title>
        <link rel="stylesheet" type="text/css" href="style/homeStyle.css">

</head>

<body>
    <?php
    include('adminHeader.php');
    ?>
    <div class="welcome">
        <h1>Welcome to bangladesh Railway website</h1>
    </div>
</body>

</html>