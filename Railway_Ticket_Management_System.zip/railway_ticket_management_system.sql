-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2020 at 04:57 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railway_ticket_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(100) NOT NULL,
  `apassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `apassword`) VALUES
(1, '1'),
(1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` int(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL,
  `caddress` varchar(100) NOT NULL,
  `cmobile` varchar(100) NOT NULL,
  `cemail` varchar(100) NOT NULL,
  `cdob` date NOT NULL,
  `cstatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `cname`, `cpassword`, `caddress`, `cmobile`, `cemail`, `cdob`, `cstatus`) VALUES
(2, 'Ashraful Islam Khan', 'f', 'Uttara,Dhaka', '01810001112', 'ashraful@gmail.com', '2007-02-27', 1),
(6, 'Rimsha', '4', 'Uttara', '01810000000', 'rimsha@gmail.com', '2018-05-21', 1),
(8, 'Abdullah Al Hamim Fahad', '1', 'Uttarkhan,Uttara,Dhaka', '01610011012', 'fahad@gmail.com', '1997-06-07', 1),
(9, 'Nusrat Songita Khan Prtottasha', '2', 'Nawabganj,Dhaka', '0181220021', 'prottasha@gmail.com', '1998-02-25', 1),
(10, 'Samia Islam Oyse', '3', 'Badda,Dhaka', '0151330031', 'samia@gmail.com', '1999-11-06', 1),
(11, 'molla', '1', 'dhaka', '01111', 'molla@gmail.com', '2020-05-27', 0),
(12, 'MR rahul', '1', 'uttara', '0168689', 'rahul@gmail.com', '2020-05-19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_registration`
--

CREATE TABLE `customer_registration` (
  `C_id` int(50) NOT NULL,
  `C_name` varchar(50) NOT NULL,
  `C_email` varchar(50) NOT NULL,
  `C_gender` varchar(50) NOT NULL,
  `C_age` varchar(50) NOT NULL,
  `C_mobile` varchar(50) NOT NULL,
  `C_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_registration`
--

INSERT INTO `customer_registration` (`C_id`, `C_name`, `C_email`, `C_gender`, `C_age`, `C_mobile`, `C_password`) VALUES
(1, 'fahad', 'king47sss@gmail.com', 'male', '33', '7184079528', 'd'),
(2, 'fahad', 'king47sss@gmail.com', 'male', '33', '7184079528', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `name`, `address`) VALUES
(2, 'fahad molla', 'uttara'),
(3, 'pro ddd', 'uttara');

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `sid` int(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `slocation` varchar(100) NOT NULL,
  `sstatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`sid`, `sname`, `slocation`, `sstatus`) VALUES
(10, 'Uttarkhan Station', 'Uttarkhan,Uttara,Dhaka', 1),
(12, 'Dhaka airpor station', 'uttara,dhaka', 1),
(13, 'kumilla Station', 'kumilla', 1),
(15, 'komolapur station', 'komolapur', 1),
(16, 'sylhet station', 'sylhet', 1),
(17, 'Rajshahi Station', 'Rajshahi ', 1),
(18, 'Khulna station', 'Khulna', 1),
(19, 'Mymensingh station', 'Mymensingh', 1),
(20, 'Jatrabari station', 'Jatrabari', 1),
(21, 'Rangpuir Station', 'Rangpur', 1),
(22, 'Barishal Station', 'Barishal', 1),
(23, 'Nowakhali Station', 'Nowakhali', 1),
(24, 'Nawabgonj Station', 'Nawabgonj,Dhaka', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `tiid` int(100) NOT NULL,
  `cid` int(100) NOT NULL,
  `trid` int(100) NOT NULL,
  `tiprice` int(100) NOT NULL,
  `tiseatno` int(100) NOT NULL,
  `titransactionno` int(100) NOT NULL,
  `tipaymentmethod` int(100) NOT NULL,
  `tistatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`tiid`, `cid`, `trid`, `tiprice`, `tiseatno`, `titransactionno`, `tipaymentmethod`, `tistatus`) VALUES
(1, 0, 9, 100, 3, 234234234, 1, 1),
(2, 2, 9, 100, 4, 10001, 2, 0),
(3, 2, 9, 100, 6, 10001, 2, 0),
(4, 2, 9, 100, 9, 10001, 2, 1),
(5, 2, 9, 100, 4, 1111111, 3, 0),
(6, 2, 9, 100, 5, 1111111, 3, 0),
(7, 2, 9, 100, 6, 1111111, 3, 1),
(8, 2, 9, 100, 7, 1111111, 3, 0),
(9, 2, 9, 100, 8, 9999, 2, 0),
(10, 2, 9, 100, 9, 9999, 2, 1),
(11, 2, 9, 100, 10, 9999, 2, 1),
(12, 2, 9, 100, 11, 9999, 2, 1),
(16, 2, 19, 220, 4, 1234234, 1, 0),
(17, 2, 19, 220, 5, 1234234, 1, 0),
(18, 2, 19, 220, 6, 1234234, 1, 0),
(19, 8, 19, 220, 7, 2147483647, 2, 0),
(20, 8, 19, 220, 8, 33333, 1, 0),
(21, 8, 19, 220, 9, 33333, 1, 0),
(22, 8, 19, 220, 10, 33333, 1, 1),
(23, 8, 19, 220, 11, 33333, 1, 1),
(24, 8, 19, 220, 12, 1234342, 2, 1),
(25, 8, 19, 220, 13, 1234342, 2, 1),
(26, 8, 19, 220, 14, 1234342, 2, 1),
(27, 8, 19, 220, 15, 1234342, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ticketclerk`
--

CREATE TABLE `ticketclerk` (
  `tid` int(100) NOT NULL,
  `tname` varchar(100) NOT NULL,
  `tpassword` varchar(100) NOT NULL,
  `temail` varchar(100) NOT NULL,
  `tmobile` varchar(100) NOT NULL,
  `tdob` date NOT NULL,
  `taddress` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticketclerk`
--

INSERT INTO `ticketclerk` (`tid`, `tname`, `tpassword`, `temail`, `tmobile`, `tdob`, `taddress`) VALUES
(7, 'fahad', '123', 'king47', '0111435345', '2020-05-14', 'dhaka'),
(8, 'sdgd', 'adsf', 'adsf', 'asdf', '2020-05-15', 'dsf'),
(9, 'fad', '', 'fad@gmail.com', '01661166234', '2020-05-19', 'kumilla');

-- --------------------------------------------------------

--
-- Table structure for table `totalbookedseatbydate`
--

CREATE TABLE `totalbookedseatbydate` (
  `toid` int(100) NOT NULL,
  `todate` date NOT NULL,
  `tobookedseat` int(100) NOT NULL,
  `trid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `totalbookedseatbydate`
--

INSERT INTO `totalbookedseatbydate` (`toid`, `todate`, `tobookedseat`, `trid`) VALUES
(2, '2020-05-21', 0, 9),
(3, '0000-00-00', 0, 11),
(4, '2020-05-20', 0, 9),
(5, '2020-05-22', 11, 9),
(6, '2020-05-18', 0, 9),
(7, '2020-05-21', 15, 19),
(8, '2020-05-22', 0, 12);

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `trid` int(100) NOT NULL,
  `trname` varchar(100) NOT NULL,
  `trprice` int(100) NOT NULL,
  `trseatcapacity` int(100) NOT NULL,
  `trstarttime` time NOT NULL,
  `trendtime` time NOT NULL,
  `trstartstation` int(100) NOT NULL,
  `trendstation` int(100) NOT NULL,
  `trstatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`trid`, `trname`, `trprice`, `trseatcapacity`, `trstarttime`, `trendtime`, `trstartstation`, `trendstation`, `trstatus`) VALUES
(9, 'Chitra Express', 100, 150, '01:03:00', '01:00:00', 12, 19, 1),
(10, 'Mudhupur Express', 300, 200, '23:00:00', '05:00:00', 15, 16, 1),
(11, 'Sundarbans Express', 350, 300, '23:30:00', '06:30:00', 12, 18, 1),
(12, 'Rupali Express', 250, 200, '00:00:00', '06:00:00', 19, 22, 1),
(13, 'Vaoyali Express', 150, 200, '13:00:00', '19:00:00', 16, 21, 1),
(14, 'Makka Express', 250, 200, '22:00:00', '04:30:00', 10, 24, 1),
(19, 'Padma Express', 220, 200, '21:00:00', '04:00:00', 10, 17, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `customer_registration`
--
ALTER TABLE `customer_registration`
  ADD PRIMARY KEY (`C_id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`tiid`);

--
-- Indexes for table `ticketclerk`
--
ALTER TABLE `ticketclerk`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `totalbookedseatbydate`
--
ALTER TABLE `totalbookedseatbydate`
  ADD PRIMARY KEY (`toid`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`trid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer_registration`
--
ALTER TABLE `customer_registration`
  MODIFY `C_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `sid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `tiid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `ticketclerk`
--
ALTER TABLE `ticketclerk`
  MODIFY `tid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `totalbookedseatbydate`
--
ALTER TABLE `totalbookedseatbydate`
  MODIFY `toid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `train`
--
ALTER TABLE `train`
  MODIFY `trid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
